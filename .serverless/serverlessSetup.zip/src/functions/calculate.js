"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event) => {
    const records = event.Records;
    records.forEach((record) => {
        console.log('Message received', record.body);
    });
};
exports.handler = handler;
